from django.shortcuts import render
from django.http import HttpResponse
def index(request):
	return HttpResponse("<h1>Welcome in Developer App</h1>")

def add(request):
	a=100
	b=200
	c=a+b
	return HttpResponse("Result is "+str(c))
def silogic(request):
	p=12000
	r=2.2
	t=2
	res = "{:0.2f}" . format((p*r*t)/100)
	return HttpResponse("Result is "+str(res))