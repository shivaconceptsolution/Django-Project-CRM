from django.apps import AppConfig


class DeveloperappConfig(AppConfig):
    name = 'developerapp'
