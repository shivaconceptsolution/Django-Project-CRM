from django.urls import path
from . import views

urlpatterns=[
path('add',views.index,name='index'),
path('',views.add,name='add'),
path('si',views.silogic,name='silogic')

]