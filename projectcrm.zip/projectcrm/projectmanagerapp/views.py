from django.shortcuts import render
from django.http import HttpResponse
def ram(request):
	x = (12,11,45,67,89)
	
	return HttpResponse(x)

