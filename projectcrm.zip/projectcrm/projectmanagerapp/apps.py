from django.apps import AppConfig


class ProjectmanagerappConfig(AppConfig):
    name = 'projectmanagerapp'
